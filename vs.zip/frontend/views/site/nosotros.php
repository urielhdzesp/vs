  <div class="jumbotron">
    <h1>Yellomile</h1> 
    <p>Bootstrap is the most popular HTML, CSS, and JS framework for developing
    responsive, mobile-first projects on the web.</p>
  </div>
  <div id="full_width" class="container-fluid full-width">
      <div class="container">
      <div id="sticker" class="row" style="background-color:rgb(242, 242, 242,0.95)">
          <div class="col-md-8 info" style="/*background-color:#f1f1af*/">
            <p class="text-center align-middle"> <b>Nombre:</b> Edgar Uriel Hernández Esparza</p>
          </div>
          <div class="col-md-4 foto" style="/*background-color:#f1e6e6*/">
              <div id="foto">
                  <img src="https://placeholdit.imgix.net/~text?txtsize=25&bg=efefef&txtclr=aaaaaa%26text%3Dno%2Bimage%26txtsize50&txt=Sin+Foto&w=155&h=155" class="img-responsive center-block">
              </div>
          </div>
      </div>
      </div>

  </div>
  <button id="boton" type="button" class="btn btn-primary">Primary</button>
  <div class="row">
      <div class="col-md-12">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
        quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
        consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
        cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
        proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
      </div> 
      <div class="col-md-12">
        Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua.
      </div>      
  </div>
<select name="codigos">

<option value="20000">Zona Centro</option>

<option value="20008">Delegación de La Secretaria de Comercio y Fomento Industrial</option>

<option value="20009">Palacio de Gobierno del Estado de Aguascalientes</option>

<option value="20010">San Cayetano</option>

<option value="20010">Colinas del Rio</option>

<option value="20010">Las Brisas</option>

<option value="20010">Olivares Santana</option>

<option value="20010">Ramon Romo Franco</option>

<option value="20016">La Fundición</option>

<option value="20016">Los Sauces</option>

<option value="20016">Fundición II</option>

<option value="20016">Colinas de San Ignacio</option>

<option value="20018">Línea de Fuego</option>

<option value="20020">Buenos Aires</option>

<option value="20020">Las Arboledas</option>

<option value="20020">Villas de San Francisco</option>

<option value="20020">Circunvalación Norte</option>

<option value="20029">Villas de La Universidad</option>

<option value="20030">El Sol</option>

<option value="20030">Industrial</option>

<option value="20030">Gremial</option>

<option value="20040">La Concordia</option>

<option value="20040">Miravalle</option>

<option value="20040">Panorama</option>

<option value="20040">Curtidores</option>

<option value="20040">Altavista</option>

<option value="20049">Colinas del Poniente</option>

<option value="20050">Primavera</option>

<option value="20050">La Fe</option>

<option value="20050">México</option>

<option value="20050">San Pablo</option>

<option value="20050">Bugambilias</option>

<option value="20050">Del Carmen</option>

<option value="20059">Heliodoro Garcia</option>

<option value="20059">Guadalupe</option>

<option value="20060">Gómez</option>

<option value="20060">Moderno</option>

<option value="20064">Valle del Rio San Pedro</option>

<option value="20070">San Marcos</option>

<option value="20070">San Marcos</option>

<option value="20070">Guadalupe Posada</option>

<option value="20078">San Marcos</option>

<option value="20080">Modelo</option>

<option value="20080">Residencial del Valle I</option>

<option value="20089">Residencial del Valle II</option>

<option value="20100">Campestre La Herradura</option>

<option value="20100">Los Vergeles</option>

<option value="20100">Jardines del Campestre</option>

<option value="20100">Club Campestre</option>

<option value="20100">Campestre 2a. Sección</option>

<option value="20100">La Querencia</option>

<option value="20100">Rancho San Antonio</option>

<option value="20100">Campestre 1a. Sección</option>

<option value="20110">La Enramada</option>

<option value="20110">Puerto las Hadas</option>

<option value="20110">Valle del Campestre</option>

<option value="20110">Las Cavas</option>

<option value="20110">Talamantes Ponce</option>

<option value="20110">Villas de Montenegro</option>

<option value="20110">Granjas del Campestre</option>

<option value="20115">Trojes de Oriente 1a Sección</option>

<option value="20115">Valle de las Trojes</option>

<option value="20115">La Paloma</option>

<option value="20115">Villa de las Trojes</option>

<option value="20115">Villas de San Nicolás</option>

<option value="20115">Trojes de Oriente 2a Sección</option>

<option value="20115">Valle de Santa Teresa</option>

<option value="20115">Barrio de Santiago</option>

<option value="20116">Trojes de Alonso</option>

<option value="20116">Santa Fe</option>

<option value="20116">La Troje</option>

<option value="20117">Aguascalientes 2000</option>

<option value="20118">Valle del Campanario</option>

<option value="20118">Las Misiones</option>

<option value="20118">Cerrada El Molino</option>

<option value="20118">Misión del Campanario</option>

<option value="20118">Cerrada del Valle</option>

<option value="20118">Trojes del Sol</option>

<option value="20118">Los Jarales</option>

<option value="20118">Cerrada de la Mezquitera</option>

<option value="20118">Trojes de Kristal</option>

<option value="20118">Valle Real</option>

<option value="20118">Terzetto</option>

<option value="20118">Las Trojes</option>

<option value="20118">Cerrada de La Misión</option>

<option value="20119">Los Calicantos</option>

<option value="20119">Lomas del Campestre 2a Sección</option>

<option value="20119">Villas del Campestre</option>

<option value="20120">Los Bosques</option>

<option value="20120">Jardines de La Concepción 1a Sección</option>

<option value="20120">Jardines de La Concepción 2a Sección</option>

<option value="20120">Rinconada los Bosques</option>

<option value="20123">Arroyo El Molino</option>

<option value="20124">Galerías</option>

<option value="20124">Residencial Altaria</option>

<option value="20126">Villa de Nuestra Señora de La Asunción Sector San Marcos</option>

<option value="20126">Privada Guadalupe</option>

<option value="20126">Rinconada del Puertecito</option>

<option value="20126">Constitución</option>

<option value="20126">Pozo Bravo Norte</option>

<option value="20126">Villa de Nuestra Señora de La Asunción Sector Guadalupe</option>

<option value="20126">Villa de Nuestra Señora de La Asunción Sector Estación</option>

<option value="20126">Residencial las Plazas</option>

<option value="20126">Montebello Della Stanza</option>

<option value="20126">Soberana Convención Revolucionaria</option>

<option value="20126">El Rosedal</option>

<option value="20126">Villa Loma Dorada</option>

<option value="20126">Los Naranjos</option>

<option value="20126">Jardines de Montebello</option>

<option value="20126">Libertad</option>

<option value="20126">El Puertecito</option>

<option value="20126">Villa Teresa</option>

<option value="20126">Villas del Río</option>

<option value="20126">Villas de La Convención</option>

<option value="20126">Lomas de La Asunción</option>

<option value="20126">Villa de Nuestra Señora de La Asunción Sector Encino</option>

<option value="20126">Villa de Nuestra Señora de La Asunción Sector Alameda</option>

<option value="20126">San José de Pozo Bravo</option>

<option value="20126">Villa Notre Dame</option>

<option value="20126">Natura</option>

<option value="20126">Rinconada Pozo Bravo</option>

<option value="20126">Pozo Bravo Sur</option>

<option value="20127">Bosques del Prado Norte</option>

<option value="20129">Lomas del Campestre 1a Sección</option>

<option value="20130">Nueva Rinconada</option>

<option value="20130">Puerta Navarra</option>

<option value="20130">Palmas del Pedregal</option>

<option value="20130">Residencial Campestre Club de Golf Norte</option>

<option value="20130">Residencial Campestre Club de Golf Sur</option>

<option value="20130">Palma Real</option>

<option value="20130">Bosques del Prado Sur</option>

<option value="20130">Fátima</option>

<option value="20130">Primo Verdad</option>

<option value="20130">Unidad Ganadera</option>

<option value="20130">Independencia de México</option>

<option value="20130">El Roble</option>

<option value="20130">San José del Arenal</option>

<option value="20135">Centro Distribuidor de Básicos</option>

<option value="20135">Agropecuario</option>

<option value="20136">La Rinconada</option>

<option value="20137">El Plateado</option>

<option value="20138">Villas del Vergel</option>

<option value="20138">Residencial Pulgas Pandas Sur</option>

<option value="20138">Residencial Pulgas Pandas Norte</option>

<option value="20138">Cerrada San Miguel</option>

<option value="20140">Las Hadas</option>

<option value="20140">Morelos</option>

<option value="20140">Andrea</option>

<option value="20146">Los Arcos</option>

<option value="20149">Industrial</option>

<option value="20150">Lomas del Cobano</option>

<option value="20150">La Estrella</option>

<option value="20150">Buenavista</option>

<option value="20150">C.T.M.</option>

<option value="20150">Macias Arellano</option>

<option value="20157">Parras</option>

<option value="20157">La Higuerilla</option>

<option value="20158">Trojes del Cobano</option>

<option value="20158">Villas del Cobano</option>

<option value="20158">Hacienda el Cobano 1a Sección</option>

<option value="20158">El Cobano</option>

<option value="20159">Alianza Ferrocarrilera</option>

<option value="20159">Bosques del Prado Oriente</option>

<option value="20160">Francisco Guel Jimenez</option>

<option value="20160">Las Viñas INFONAVIT</option>

<option value="20164">Santa Anita 4a Sección</option>

<option value="20169">Santa Anita 2a Sección</option>

<option value="20169">Santa Anita</option>

<option value="20170">Rodolfo Landeros Gallegos</option>

<option value="20170">Zona Militar</option>

<option value="20170">El Maguey</option>

<option value="20170">Las Cumbres</option>

<option value="20170">S.T.E.M.A.</option>

<option value="20170">Lic Benito Juárez</option>

<option value="20170">Villa Bonita</option>

<option value="20170">Nazario Ortiz Garza</option>

<option value="20172">Lic Benito Palomino Dena</option>

<option value="20172">Cumbres III</option>

<option value="20172">Claustros Loma Dorada</option>

<option value="20174">Vista de las Cumbres</option>

<option value="20174">Los Laureles 3ra. Sección</option>

<option value="20174">Paseos del Sol</option>

<option value="20174">Villas de las Fuentes</option>

<option value="20174">Los Laureles 2a Sección</option>

<option value="20174">Mirador de Las Culturas III</option>

<option value="20174">Lomas de Bellavista</option>

<option value="20174">Villas de La Loma</option>

<option value="20174">Miradores de Santa Elena</option>

<option value="20174">Los Laureles</option>

<option value="20174">Colinas de Oriente</option>

<option value="20174">Mirador de Las Culturas</option>

<option value="20174">Mirador de las Culturas 2a Sección</option>

<option value="20174">Los Pericos</option>

<option value="20175">Ejido las Cumbres</option>

<option value="20175">Lomas de Oriente 1a Sección</option>

<option value="20175">J Refugio Esparza Reyes</option>

<option value="20175">Lomas de Oriente 2da. Sección</option>

<option value="20175">Lomas de Oriente 3ra. Sección</option>

<option value="20175">La Hojarasca</option>

<option value="20177">C.N.O.P. Oriente</option>

<option value="20179">Pensadores Mexicanos</option>

<option value="20179">Santa Margarita</option>

<option value="20179">Cerro Alto</option>

<option value="20179">Luis Ortega Douglas</option>

<option value="20179">Las Cumbres II</option>

<option value="20179">Las Cumbres</option>

<option value="20179">Pintores Mexicanos</option>

<option value="20179">Progreso</option>

<option value="20180">Ferronales</option>

<option value="20180">Rinconada de La Alameda</option>

<option value="20180">Lomas de Santa Anita</option>

<option value="20180">Bosques de La Alameda</option>

<option value="20180">Nueva Alameda</option>

<option value="20180">Del Trabajo</option>

<option value="20180">Luis Gómez Zepeda (ferronales)</option>

<option value="20190">La Mancha</option>

<option value="20190">La Hacienda</option>

<option value="20190">Héroes</option>

<option value="20196">Ojocaliente I</option>

<option value="20196">Ojocaliente INEGI</option>

<option value="20196">Villerías</option>

<option value="20196">J. Guadalupe Posada</option>

<option value="20196">Ojocaliente 3a Sección</option>

<option value="20196">Colinas de San Patricio</option>

<option value="20196">El Rocio</option>

<option value="20196">Valle del Bicentenario</option>

<option value="20196">Paseo de los Cactus</option>

<option value="20196">José Guadalupe Peralta Gámez</option>

<option value="20196">Ojocaliente INEGI II</option>

<option value="20196">Terra Nova</option>

<option value="20196">Real del Sol</option>

<option value="20196">José Guadalupe Peralta Gámez II</option>

<option value="20196">Haciendas de Aguascalientes 1a Sección</option>

<option value="20196">Real de Haciendas</option>

<option value="20196">Valle de los Cactus</option>

<option value="20196">Balcones de Oriente</option>

<option value="20196">Balcones del Valle</option>

<option value="20196">Solidaridad 1a Sección</option>

<option value="20196">Vistas de Oriente</option>

<option value="20198">Ex Hacienda Ojocaliente</option>

<option value="20198">Misión Alameda</option>

<option value="20198">Ejido Ojocaliente</option>

<option value="20199">Ojo Caliente IV</option>

<option value="20199">El Riego</option>

<option value="20199">Fidel Velázquez INFONAVIT</option>

<option value="20199">Municipio Libre</option>

<option value="20200">José Vasconcelos Calderón</option>

<option value="20200">Ex Hacienda La Cantera</option>

<option value="20200">Bellavista</option>

<option value="20200">Porta Canteras</option>

<option value="20200">El Quelite</option>

<option value="20200">Loma Bonita</option>

<option value="20200">Villas de La Cantera 1a Sección</option>

<option value="20200">San Nicolás 1ra. Sección</option>

<option value="20200">Fuentes del Lago</option>

<option value="20200">Villas del Mediterráneo</option>

<option value="20200">Veteranos de La Revolución</option>

<option value="20200">Lic Manuel Gómez Morin</option>

<option value="20200">San Nicolás</option>

<option value="20200">Olinda</option>

<option value="20205">Educación Álamos</option>

<option value="20205">Nueva España</option>

<option value="20206">Lic. José López Portillo</option>

<option value="20206">La Barranquilla</option>

<option value="20206">Los Barandales</option>

<option value="20207">Canteras de San Javier</option>

<option value="20207">Rinconada San José</option>

<option value="20208">Canteras de San José</option>

<option value="20210">España</option>

<option value="20210">La Barranca de Guadalupe</option>

<option value="20210">Pirules INFONAVIT</option>

<option value="20210">Circunvalación Poniente</option>

<option value="20216">Jardines de los Pirules</option>

<option value="20217">Residencial los Pirules</option>

<option value="20218">Jardines del Lago</option>

<option value="20218">San Agustín</option>

<option value="20218">Canteras de Santa Imelda</option>

<option value="20218">San Martin de La Cantera</option>

<option value="20218">Francisco Villa</option>

<option value="20218">Canteras de San Agustin</option>

<option value="20218">Los Eucaliptos</option>

<option value="20218">Santa Imelda</option>

<option value="20218">Los Eucaliptos 2a. Sección</option>

<option value="20219">Parque Industrial el Vergel</option>

<option value="20219">El Edén</option>

<option value="20219">Misión Juan Pablo II</option>

<option value="20220">Las Flores</option>

<option value="20220">Vivienda Popular</option>

<option value="20229">Las Torres</option>

<option value="20230">Santa Elena</option>

<option value="20230">Obraje</option>

<option value="20230">Las Américas</option>

<option value="20234">Agricultura</option>

<option value="20234">Mesonero</option>

<option value="20235">Valle Dorado</option>

<option value="20235">El Dorado 2a Sección</option>

<option value="20235">Villa Jardín 1a Sección</option>

<option value="20235">El Dorado 1a Sección</option>

<option value="20235">Villa Jardín 2a Sección</option>

<option value="20236">Jardines de Santa Elena</option>

<option value="20237">Montebello</option>

<option value="20237">Hermanos Carreón</option>

<option value="20238">Santa Elena 2a Sección</option>

<option value="20239">La Fuente</option>

<option value="20240">Triana</option>

<option value="20240">Los Virreyes</option>

<option value="20240">El Llanito</option>

<option value="20240">Residencial Cosío</option>

<option value="20240">La Luna</option>

<option value="20240">El Laurel</option>

<option value="20240">La Salud</option>

<option value="20240">Residencial el Encino</option>

<option value="20240">El Encino</option>

<option value="20240">Triana</option>

<option value="20247">San Fernando INFONAVIT</option>

<option value="20248">Jardines de Triana</option>

<option value="20249">Gámez</option>

<option value="20250">Jardines de La Cruz</option>

<option value="20250">Villas de Kristal</option>

<option value="20250">La Huerta</option>

<option value="20250">San Luis</option>

<option value="20250">Héroes de Aguascalientes</option>

<option value="20250">Jesús Gómez Portugal</option>

<option value="20255">Bona Gens</option>

<option value="20255">INFONAVIT Los Volcanes</option>

<option value="20256">Ojocaliente FOVISSSTE II</option>

<option value="20256">Rinconada de La Cruz</option>

<option value="20256">Villas de Ojocaliente</option>

<option value="20256">FOVISSSTE Ojocaliente I</option>

<option value="20256">Ojocaliente las Torres</option>

<option value="20256">Parque y Presa del Cedazo</option>

<option value="20257">Lázaro Cárdenas</option>

<option value="20259">La Estación</option>

<option value="20259">La Purísima</option>

<option value="20260">Ojo de Agua</option>

<option value="20260">Jesús Terán Peredo</option>

<option value="20260">IV Centenario</option>

<option value="20260">Rinconada El Cedazo</option>

<option value="20260">Sidusa</option>

<option value="20260">Vivienda Militar</option>

<option value="20263">Ojo de Agua de Palmitas</option>

<option value="20263">Salto de Ojocaliente</option>

<option value="20263">Cima del Chapulín</option>

<option value="20263">San Ángel</option>

<option value="20263">San Jorge</option>

<option value="20263">Agua Clara</option>

<option value="20263">Balcones de Ojocaliente</option>

<option value="20263">Villa las Palmas</option>

<option value="20263">Bajío de las Palmas</option>

<option value="20263">Lomas del Gachupín</option>

<option value="20263">Solidaridad 2a Sección</option>

<option value="20263">Cielo Claro</option>

<option value="20263">El Cedazo</option>

<option value="20263">La Lomita</option>

<option value="20263">Lomas del Chapulín</option>

<option value="20263">Solidaridad 3a Sección</option>

<option value="20263">Tierra Buena</option>

<option value="20263">Cobano de Palmitas</option>

<option value="20263">Villa Taurina</option>

<option value="20264">Vista del Sol 3a Sección</option>

<option value="20264">Morelos INFONAVIT</option>

<option value="20264">Vista del Sol 2a Sección</option>

<option value="20265">Ojo de Agua INFONAVIT</option>

<option value="20266">La Cruz</option>

<option value="20266">Jardines del Sol</option>

<option value="20266">Vista del Sol 1a Sección</option>

<option value="20266">Misión de Santa Fe</option>

<option value="20267">Lic Primo Verdad INEGI</option>

<option value="20267">Jardines de La Convención</option>

<option value="20267">S.T.E.M.A.</option>

<option value="20267">Ojo de Agua FOVISSSTE 1a Sección</option>

<option value="20268">Fuentes de La Asunción</option>

<option value="20269">Jardines de La Luz</option>

<option value="20270">Jardines de La Asunción</option>

<option value="20270">El Caminero</option>

<option value="20270">Jardines de Aguascalientes</option>

<option value="20270">Lindavista</option>

<option value="20270">Los Cedros</option>

<option value="20270">México</option>

<option value="20270">Las Canoas</option>

<option value="20270">Bulevar</option>

<option value="20276">Jardines de las Bugambilias</option>

<option value="20276">Jardines del Parque</option>

<option value="20277">Rinconada del Parque</option>

<option value="20277">Pirámides</option>

<option value="20277">Residencial del Parque</option>

<option value="20278">Jardines de las Fuentes</option>

<option value="20278">Diana</option>

<option value="20280">Jardines del Sur</option>

<option value="20280">La Luz</option>

<option value="20280">Prados de Villasunción</option>

<option value="20280">San Francisco del Arenal</option>

<option value="20280">San Pedro</option>

<option value="20280">Casasolida</option>

<option value="20280">Martinez Dominguez</option>

<option value="20280">Torres de San Francisco</option>

<option value="20280">Central de Abastos</option>

<option value="20280">Prados del Sur</option>

<option value="20280">Trojes del Sur</option>

<option value="20283">Parque Industrial Siglo XXI</option>

<option value="20283">Parque Industrial Siglo XXI (Ampliación)</option>

<option value="20284">Villas del Oeste</option>

<option value="20284">Villas de Santa Rosa</option>

<option value="20284">La Casita</option>

<option value="20284">Vista del Sur</option>

<option value="20284">La Estancia</option>

<option value="20284">INFONAVIT Potreros del Oeste</option>

<option value="20285">Versalles 2a Sección</option>

<option value="20285">Versalles 1a Sección</option>

<option value="20286">Villas del Pilar 1a Sección</option>

<option value="20286">Rancho Santa Mónica</option>

<option value="20286">Providencia</option>

<option value="20286">Rinconada Santa Mónica</option>

<option value="20286">Villa Capri</option>

<option value="20286">Paseos de Santa Mónica</option>

<option value="20286">Vicente Guerrero</option>

<option value="20286">Villas San Antonio</option>

<option value="20287">Insurgentes</option>

<option value="20288">Bulevares 2a. Sección</option>

<option value="20288">Bulevares 1a. Sección</option>

<option value="20289">Pilar Blanco INFONAVIT</option>

<option value="20290">Parque Industrial ALTEC</option>

<option value="20290">Ciudad Industrial</option>

<option value="20290">Vista Alegre</option>

<option value="20290">Plaza Vestir</option>

<option value="20291">Centro SCT Aguascalientes</option>

<option value="20296">Villas de Bonaterra</option>

<option value="20296">Residencial San Javier</option>

<option value="20296">Villa Sur</option>

<option value="20296">Rústicos Calpulli</option>

<option value="20296">San Francisco de los Arteaga</option>

<option value="20297">Casa Blanca</option>

<option value="20297">Jardines de Casanueva</option>

<option value="20297">Jardines de Casablanca</option>

<option value="20298">Morelos I</option>

<option value="20298">Morelos 2a Sección</option>

<option value="20298">Lomas del Sur</option>

<option value="20298">Lomas de Vistabella 2a. Sección</option>

<option value="20298">Lomas del Mirador IV Sección</option>

<option value="20298">San Sebastián</option>

<option value="20298">Villas de Ajedrez</option>

<option value="20298">Lomas del Mirador I Sección</option>

<option value="20298">Misión de Santa Lucía</option>

<option value="20298">Lomas del Mirador III Sección</option>

<option value="20298">Solidaridad 4a Sección</option>

<option value="20298">Lomas del Mirador V Sección</option>

<option value="20298">Hacienda San Marcos</option>

<option value="20298">Emiliano Zapata</option>

<option value="20298">Ladrilleras Los Arellano</option>

<option value="20298">Valle del Cedazo</option>

<option value="20298">Lomas de Vistabella</option>

<option value="20298">Lomas de Nueva York</option>

<option value="20298">Lomas del Mirador II Sección</option>

<option value="20298">Paseos de San Antonio</option>

<option value="20298">Laureles del Sur</option>

<option value="20298">Condominio La terraza</option>

<option value="20299">Lomas del Ajedrez</option>

<option value="20299">Lomas de San Jorge</option>

<option value="20299">Reencuentro</option>

<option value="20299">Lomas de San Jorge 2a. Sección</option>

<option value="20299">Mujeres Ilustres</option>

<option value="20299">Periodistas</option>

<option value="20299">Villalta</option>

<option value="20299">Fundadores</option>

<option value="20299">Lomas Altas</option>

<option value="20310">Los Negritos</option>

<option value="20310">La Loma de los Negritos</option>

<option value="20310">San Felipe (Viñedos San Felipe)</option>

<option value="20311">Sandovales</option>

<option value="20311">Trojes de Alonso</option>

<option value="20311">Coyotes Norte</option>

<option value="20312">Rio Curtidores</option>

<option value="20313">Hacienda Nueva</option>

<option value="20313">Cuauhtémoc</option>

<option value="20314">Cariñan</option>

<option value="20314">Torrecillas</option>

<option value="20315">Viñedos Valle Redondo</option>

<option value="20316">Lomas del Picacho</option>

<option value="20316">El Picacho</option>

<option value="20317">Santa Cruz de La Presa</option>

<option value="20318">La Cantera</option>

<option value="20319">Cereso (para Varones y Mujeres)</option>

<option value="20320">Gral. José María Morelos y Pavón</option>

<option value="20320">Cañada Honda</option>

<option value="20320">Las Cañadas</option>

<option value="20321">El Cortijo</option>

<option value="20321">La Escondida</option>

<option value="20322">La Presa</option>

<option value="20322">San Vicente</option>

<option value="20323">Santa María de Gallardo</option>

<option value="20324">Jaltomate</option>

<option value="20326">La Rioja</option>

<option value="20326">San Ignacio III</option>

<option value="20326">Rinconada San Ignacio</option>

<option value="20326">San Ignacio</option>

<option value="20326">La Soledad</option>

<option value="20326">San Ignacio 3</option>

<option value="20326">San Ignacio II</option>

<option value="20326">Puesta del Sol</option>

<option value="20326">Ex Hacienda San Ignacio</option>

<option value="20326">La Perla</option>

<option value="20328">Los Pocitos</option>

<option value="20328">Parque Industrial Tecno Polo</option>

<option value="20328">Sandovales de Arriba</option>

<option value="20329">Las Plazuelas</option>

<option value="20329">Contadero</option>

<option value="20329">Santa María</option>

<option value="20329">La Punta Campestre</option>

<option value="20329">Puerta del Sol</option>

<option value="20329">Rincón Andaluz</option>

<option value="20329">Torre Campestre Santa María</option>

<option value="20329">La Joya</option>

<option value="20329">Río Viejo</option>

<option value="20340">Parque Industrial Logística Automotriz</option>

<option value="20340">Arellano</option>

<option value="20340">Buena Vista de Peñuelas</option>

<option value="20340">Peñuelas</option>

<option value="20340">Cieneguilla</option>

<option value="20341">Salto de los Salados</option>

<option value="20341">El Salto de Ojocaliente</option>

<option value="20341">La Huerta</option>

<option value="20342">San Francisco</option>

<option value="20342">San Gerardo</option>

<option value="20344">Lic Jesús Terán Villa</option>

<option value="20345">Montoro</option>

<option value="20346">Los Caños</option>

<option value="20348">San Antonio de Peñuelas</option>

<option value="20349">Aguascalientes (Lic. Jesús Terán Peredo)</option>

<option value="20363">San José de La Ordeña</option>

<option value="20363">San Antonio de los Pedroza</option>

<option value="20364">San Nicolás de Arriba</option>

<option value="20364">La Soledad</option>

<option value="20364">Cartagena 1947</option>

<option value="20364">San Nicolás de Enmedio</option>

<option value="20366">La Herrada</option>

<option value="20366">El Colorado (el Soyatal)</option>

<option value="20366">El Conejal</option>

<option value="20367">El Trigo</option>

<option value="20367">Norias del Ojocaliente</option>

<option value="20367">El Rocio</option>

<option value="20369">El Malacate</option>

<option value="20369">Dolores</option>

<option value="20370">La Pila</option>

<option value="20370">El Puerto</option>

<option value="20371">La Cotorra</option>

<option value="20371">Ciudad de los Niños</option>

<option value="20372">El Niágara</option>

<option value="20372">Granjas Fátima</option>

<option value="20372">Cabecita 3 Marías</option>

<option value="20373">El Salitre</option>

<option value="20373">El Ocote</option>

<option value="20375">El Tanque de los Jimenez</option>

<option value="20375">El Cedazo (cedazo de San Antonio)</option>

<option value="20375">Campestre Bosques de Las Lomas</option>

<option value="20375">El Refugio de Peñuelas</option>

<option value="20376">Centro de Arriba (El Taray)</option>

<option value="20377">Cieneguilla</option>

<option value="20377">San Pedro Cieneguilla</option>

<option value="20379">Los Dolores</option>

<option value="20384">El Hotelito</option>

<option value="20384">Paso Hondo</option>

<option value="20384">Norias del Paso Hondo</option>

<option value="20385">Santa Gertrudis</option>

<option value="20386">Tanque de Guadalupe</option>

<option value="20386">El Duraznillo</option>

<option value="20389">Los Duron</option>

<option value="20389">Soledad de Abajo</option>

<option value="20389">Congregación Matamoros</option>

<option value="20390">San José</option>

<option value="20390">Villa Campestre San José del Monte</option>

<option value="20391">Agostaderito</option>

<option value="20392">Cotorina de Ejido</option>

<option value="20392">Campestre el Potrerillo</option>

<option value="20392">Montoro</option>

<option value="20392">Universidad Autónoma de Aguascalientes Campus Sur</option>

<option value="20394">Cañada Grande de Cotorina</option>

<option value="20394">Coyotes Sur</option>

<option value="20395">San Bartolo</option>

<option value="20395">Los Cuervos (los Ojos de Agua)</option>

<option value="20396">El Refugio de Peñuelas</option>

<option value="20396">Peñuelas</option>

<option value="20396">Peñuelas</option>

<option value="20399">El Turicate</option>

</select>
  <div class="row" id="parrafo1">
      
  </div>

<?php
$this->registerJsFile(
    '@web/js/plugins/garand-sticky-73b0fbe/jquery.sticky.js',
    ['depends' => [\yii\web\JqueryAsset::className()]]
);
$this->registerJsFile(
    '@web/js/nosotros.js',
    ['depends' => [\yii\web\JqueryAsset::className()]]
);


$this->registerCss("
    .full-width {
        width: 100vw;
        position: relative;
        margin-left: -50vw;
        left: 50%;
        padding: 0% 0% 2% 0%;
    }
    #sticker{
    left: 0px;
    right: 0px;
    -webkit-box-shadow: 0px 4px 20px 0px rgba(0,0,0,0.48);
    -moz-box-shadow: 0px 4px 20px 0px rgba(0,0,0,0.48);
    box-shadow: 0px 4px 20px 0px rgba(0,0,0,0.48);
    }
");
?> 